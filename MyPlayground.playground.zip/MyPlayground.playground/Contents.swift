//func sort(numbers:[Int],_ how:(_ num1:Int,_ num2:Int)->(Int))->([Int]){
//    var numbersTemp=numbers
//    for var i in 0..<numbersTemp.count-1{
//        for var j in i+1..<numbersTemp.count{
//           let compare=how(numbersTemp[i],numbersTemp[j])
//            if(compare<0){
//                let temp=numbersTemp[i]
//                    numbersTemp[i]=numbersTemp[j]
//                    numbersTemp[j]=temp
//
//            }
//
//        }
//    }
//    return numbersTemp
//}
//let number=[9,2,15,9,7,11,3]
//print(number)
////1. NORMAL CLOSURE
//func normalClosure(_ num1:Int,_ num2:Int)->Int{
//    return num2-num1
//}
//print("after sort",sort(numbers:number, normalClosure))
////=====================
////2. INLINE CLOSURE
//print("after sort",sort(numbers:number, {(num1:Int,num2:Int)->Int in
//                            print("hehe")
//                            return num2-num1}))
////
////======================
////3. Inferring Type
//print(sort(numbers: number, {num1,num2  in print("hehe")
//            return num2-num1}))
////======================
////4. Implicit Returns from Single-Expression Closures
//print(sort(numbers: number, {num1,num2 in num2-num1}))
////======================
////5. Shorthand Argument Names
//print(sort(numbers: number, {$1-$0}))
////======================
////6. Operator Methods
//
//func equalString(handle:(_ seq1:String,_ seq2:String)->(Bool))->Bool{
//    var seqOne="a"
//    var seqTwo="a"
//    return(handle(seqOne,seqTwo))
//}
//print(equalString(handle: ==))
//class Pig{
//    var name:String="alex"
//}
//var myPig=Pig()
//myPig.name
let intNum=1
let floatNum=3.2
let combineNum:Float=Double(intNum) + floatNum
print(combineNum)
